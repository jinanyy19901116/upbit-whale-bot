CREATE TABLE IF NOT EXISTS snapshots (
    id BIGSERIAL PRIMARY KEY,
    snapshot_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    exchange TEXT NOT NULL,
    symbol TEXT NOT NULL,
    market_type TEXT,
    last_price DOUBLE PRECISION,
    price_change_pct_24h DOUBLE PRECISION,
    quote_volume_24h DOUBLE PRECISION,
    base_volume_24h DOUBLE PRECISION,
    high_price_24h DOUBLE PRECISION,
    low_price_24h DOUBLE PRECISION,
    open_interest DOUBLE PRECISION,
    open_interest_value_usd DOUBLE PRECISION,
    funding_rate DOUBLE PRECISION,
    signal_score DOUBLE PRECISION,
    signal_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_snapshots_symbol_exchange_time
ON snapshots(symbol, exchange, snapshot_at DESC);

CREATE TABLE IF NOT EXISTS alerts_sent (
    id BIGSERIAL PRIMARY KEY,
    sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    symbol TEXT NOT NULL,
    fingerprint TEXT NOT NULL UNIQUE
);
